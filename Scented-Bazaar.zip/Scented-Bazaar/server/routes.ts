import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // === Products ===
  app.get(api.products.list.path, async (req, res) => {
    const products = await storage.getProducts();
    res.json(products);
  });

  app.get(api.products.get.path, async (req, res) => {
    const product = await storage.getProduct(Number(req.params.id));
    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }
    res.json(product);
  });

  // === Cart ===
  app.get(api.cart.list.path, async (req, res) => {
    const items = await storage.getCartItems(req.params.sessionId);
    res.json(items);
  });

  app.post(api.cart.addItem.path, async (req, res) => {
    try {
      const input = api.cart.addItem.input.parse(req.body);
      const item = await storage.addToCart(input);
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.delete(api.cart.removeItem.path, async (req, res) => {
    await storage.removeFromCart(Number(req.params.id));
    res.status(204).send();
  });

  app.patch(api.cart.updateItem.path, async (req, res) => {
    try {
      const input = api.cart.updateItem.input.parse(req.body);
      const item = await storage.updateCartItem(Number(req.params.id), input.quantity);
      res.json(item);
    } catch (err) {
        // Handle error appropriately
        res.status(400).json({ message: "Invalid input" });
    }
  });

  // === Contact ===
  app.post(api.contact.submit.path, async (req, res) => {
    try {
      const input = api.contact.submit.input.parse(req.body);
      const contact = await storage.createContact(input);
      res.status(201).json(contact);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Seed Data
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const products = await storage.getProducts();
  if (products.length === 0) {
    const seedProducts = [
      {
        name: "Midnight Rose",
        description: "An enchanting blend of bulgarian rose, jasmine, and dark amber. Perfect for evening wear.",
        price: 12500, // $125.00
        imageUrl: "https://images.unsplash.com/photo-1594035910387-fea477942698?w=800&q=80",
        category: "perfume",
        brand: "Lumière"
      },
      {
        name: "Oceanic Drift",
        description: "Fresh notes of sea salt, bergamot, and driftwood. A crisp, modern fragrance for men.",
        price: 9500, // $95.00
        imageUrl: "https://images.unsplash.com/photo-1523293188086-b51292955f2c?w=800&q=80",
        category: "cologne",
        brand: "Azure"
      },
      {
        name: "Golden Oud",
        description: "Rich oud wood with hints of vanilla and spice. A luxurious, long-lasting scent.",
        price: 18000, // $180.00
        imageUrl: "https://images.unsplash.com/photo-1541643600914-78b084683601?w=800&q=80",
        category: "perfume",
        brand: "Lumière"
      },
      {
        name: "Velvet Orchid",
        description: "A sophisticated floral arrangement with orchid, magnolia, and musk.",
        price: 11000, // $110.00
        imageUrl: "https://images.unsplash.com/photo-1588405748880-12d1d2a59f75?w=800&q=80",
        category: "perfume",
        brand: "Fleur"
      },
      {
        name: "Citrus & Sage",
        description: "Zesty lemon combined with earthy sage. A refreshing everyday scent.",
        price: 8500, // $85.00
        imageUrl: "https://images.unsplash.com/photo-1592945403244-b3fbafd7f539?w=800&q=80",
        category: "cologne",
        brand: "Azure"
      },
      {
        name: "The Collection Gift Set",
        description: "A curated selection of our finest fragrances in travel-sized bottles.",
        price: 15000, // $150.00
        imageUrl: "https://images.unsplash.com/photo-1615634260167-c8cdede054de?w=800&q=80",
        category: "gift-set",
        brand: "Lumière"
      }
    ];

    for (const p of seedProducts) {
      await storage.createProduct(p);
    }
  }
}
