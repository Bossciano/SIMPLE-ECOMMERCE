import { Link } from "wouter";
import { type Product } from "@shared/schema";
import { motion } from "framer-motion";

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  const formattedPrice = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(product.price / 100);

  return (
    <Link href={`/product/${product.id}`} className="group block h-full">
      <motion.div 
        whileHover={{ y: -5 }}
        className="bg-white p-4 h-full flex flex-col transition-shadow duration-300 hover:shadow-xl"
      >
        <div className="aspect-[3/4] overflow-hidden bg-secondary relative mb-6">
          <img 
            src={product.imageUrl} 
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors duration-300" />
        </div>
        
        <div className="text-center mt-auto">
          <p className="text-xs uppercase tracking-widest text-muted-foreground mb-2">
            {product.brand}
          </p>
          <h3 className="font-display text-xl mb-2 group-hover:text-primary transition-colors">
            {product.name}
          </h3>
          <p className="font-medium text-foreground/80">
            {formattedPrice}
          </p>
        </div>
      </motion.div>
    </Link>
  );
}
