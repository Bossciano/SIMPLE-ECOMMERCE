import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="bg-foreground text-background py-16 mt-24">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-2">
            <h3 className="text-2xl font-display font-bold mb-6">SCENT.</h3>
            <p className="text-white/60 max-w-sm leading-relaxed">
              Crafting memories through the art of perfumery. 
              Our fragrances are designed to evoke emotion and define moments.
            </p>
          </div>
          
          <div>
            <h4 className="text-lg font-display mb-6">Explore</h4>
            <ul className="space-y-4">
              <li><Link href="/products" className="text-white/60 hover:text-primary transition-colors">Collection</Link></li>
              <li><Link href="/about" className="text-white/60 hover:text-primary transition-colors">Our Story</Link></li>
              <li><Link href="/stores" className="text-white/60 hover:text-primary transition-colors">Stores</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-display mb-6">Legal</h4>
            <ul className="space-y-4">
              <li><a href="#" className="text-white/60 hover:text-primary transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-white/60 hover:text-primary transition-colors">Terms of Service</a></li>
              <li><a href="#" className="text-white/60 hover:text-primary transition-colors">Returns</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-white/10 mt-16 pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-white/40">
          <p>&copy; 2024 SCENT. All rights reserved.</p>
          <p className="mt-4 md:mt-0">Designed for elegance.</p>
        </div>
      </div>
    </footer>
  );
}
