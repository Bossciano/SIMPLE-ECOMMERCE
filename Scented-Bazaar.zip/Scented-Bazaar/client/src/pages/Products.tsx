import { useProducts } from "@/hooks/use-products";
import { ProductCard } from "@/components/ProductCard";
import { useState } from "react";
import { Filter } from "lucide-react";

export default function Products() {
  const { data: products, isLoading } = useProducts();
  const [activeCategory, setActiveCategory] = useState<string>("all");

  const categories = ["all", "perfume", "cologne", "gift-set"];

  const filteredProducts = products?.filter(
    (p) => activeCategory === "all" || p.category === activeCategory
  ) || [];

  return (
    <div className="min-h-screen pt-12 pb-24">
      <div className="container-custom">
        <header className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-display mb-4">The Collection</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Discover your signature scent from our exclusive range of luxury fragrances.
          </p>
        </header>

        {/* Filters */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-6 py-2 uppercase tracking-widest text-xs transition-all duration-300 ${
                activeCategory === cat
                  ? "bg-foreground text-background"
                  : "bg-transparent border border-border text-foreground hover:border-primary hover:text-primary"
              }`}
            >
              {cat.replace("-", " ")}
            </button>
          ))}
        </div>

        {/* Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
              <div key={i} className="h-[400px] bg-secondary animate-pulse" />
            ))}
          </div>
        ) : filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-24">
            <p className="text-xl font-display text-muted-foreground">No products found in this category.</p>
            <button 
              onClick={() => setActiveCategory("all")}
              className="mt-4 text-primary underline underline-offset-4"
            >
              View all products
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
