import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertContactSchema } from "@shared/schema";
import { type InsertContact } from "@shared/routes";
import { useContact } from "@/hooks/use-contact";
import { Loader2 } from "lucide-react";

export default function Contact() {
  const mutation = useContact();
  const form = useForm<InsertContact>({
    resolver: zodResolver(insertContactSchema),
    defaultValues: {
      name: "",
      email: "",
      message: "",
    },
  });

  const onSubmit = (data: InsertContact) => {
    mutation.mutate(data, {
      onSuccess: () => form.reset(),
    });
  };

  return (
    <div className="min-h-screen py-16 md:py-24">
      <div className="container-custom max-w-4xl">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-display mb-6">Contact Us</h1>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Have questions about our fragrances? Our concierge team is at your service.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-24">
          <div>
            <div className="mb-8">
              <h3 className="font-display text-xl mb-4">Customer Service</h3>
              <p className="text-muted-foreground leading-relaxed">
                Monday through Friday<br />
                9am to 6pm EST
              </p>
            </div>
            
            <div className="mb-8">
              <h3 className="font-display text-xl mb-4">Visit Our Boutique</h3>
              <p className="text-muted-foreground leading-relaxed">
                123 Luxury Avenue<br />
                New York, NY 10012<br />
                United States
              </p>
            </div>
            
            <div>
              <h3 className="font-display text-xl mb-4">Email Us</h3>
              <a href="mailto:concierge@scent.com" className="text-primary hover:underline">
                concierge@scent.com
              </a>
            </div>
          </div>

          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div>
              <label htmlFor="name" className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">
                Name
              </label>
              <input
                id="name"
                {...form.register("name")}
                className="input-luxury"
                placeholder="Your full name"
              />
              {form.formState.errors.name && (
                <p className="text-destructive text-xs mt-1">{form.formState.errors.name.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="email" className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">
                Email
              </label>
              <input
                id="email"
                type="email"
                {...form.register("email")}
                className="input-luxury"
                placeholder="your@email.com"
              />
              {form.formState.errors.email && (
                <p className="text-destructive text-xs mt-1">{form.formState.errors.email.message}</p>
              )}
            </div>

            <div>
              <label htmlFor="message" className="block text-xs uppercase tracking-widest text-muted-foreground mb-2">
                Message
              </label>
              <textarea
                id="message"
                {...form.register("message")}
                rows={5}
                className="input-luxury resize-none"
                placeholder="How can we assist you?"
              />
              {form.formState.errors.message && (
                <p className="text-destructive text-xs mt-1">{form.formState.errors.message.message}</p>
              )}
            </div>

            <button 
              type="submit" 
              disabled={mutation.isPending}
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              {mutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" /> Sending...
                </>
              ) : (
                "Send Message"
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
