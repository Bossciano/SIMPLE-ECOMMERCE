import { useCart } from "@/hooks/use-cart";
import { Link } from "wouter";
import { Minus, Plus, Trash2, ArrowRight } from "lucide-react";
import { Loader2 } from "lucide-react";

export default function Cart() {
  const { cartItems, isLoading, updateQuantity, removeFromCart } = useCart();

  const subtotal = cartItems.reduce((acc, item) => {
    return acc + (item.quantity * (item.product?.price || 0));
  }, 0);

  const formattedSubtotal = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(subtotal / 100);

  if (isLoading) {
    return (
      <div className="h-[60vh] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (cartItems.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-6 container-custom text-center">
        <h1 className="text-3xl font-display">Your Bag is Empty</h1>
        <p className="text-muted-foreground max-w-md">
          Looks like you haven't added anything to your cart yet.
          Discover our collection of fine fragrances.
        </p>
        <Link href="/products" className="btn-primary">
          Start Shopping
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen py-12">
      <div className="container-custom">
        <h1 className="text-3xl md:text-4xl font-display mb-12">Shopping Bag ({cartItems.length})</h1>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-8">
            {cartItems.map((item) => (
              <div key={item.id} className="flex gap-6 py-6 border-b border-border last:border-0">
                <div className="w-24 h-32 bg-secondary flex-shrink-0">
                  {item.product?.imageUrl && (
                    <img 
                      src={item.product.imageUrl} 
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
                
                <div className="flex-1 flex flex-col justify-between">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-display text-lg">{item.product?.name}</h3>
                      <p className="text-sm text-muted-foreground">{item.product?.brand}</p>
                    </div>
                    <p className="font-medium">
                      {new Intl.NumberFormat('en-US', {
                        style: 'currency',
                        currency: 'USD',
                      }).format((item.product?.price || 0) / 100)}
                    </p>
                  </div>

                  <div className="flex justify-between items-end">
                    <div className="flex items-center border border-border">
                      <button 
                        onClick={() => updateQuantity({ id: item.id, quantity: Math.max(1, item.quantity - 1) })}
                        className="p-2 hover:bg-secondary transition-colors"
                        disabled={item.quantity <= 1}
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-8 text-center text-sm">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity({ id: item.id, quantity: item.quantity + 1 })}
                        className="p-2 hover:bg-secondary transition-colors"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                    
                    <button 
                      onClick={() => removeFromCart(item.id)}
                      className="text-sm text-muted-foreground hover:text-destructive underline decoration-dotted underline-offset-4 flex items-center gap-1 transition-colors"
                    >
                      <Trash2 className="w-3 h-3" /> Remove
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="bg-secondary/20 p-8 border border-border sticky top-24">
              <h2 className="text-xl font-display mb-6">Order Summary</h2>
              
              <div className="space-y-4 mb-6 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Subtotal</span>
                  <span>{formattedSubtotal}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Shipping</span>
                  <span>Calculated at checkout</span>
                </div>
              </div>
              
              <div className="border-t border-border pt-4 mb-8">
                <div className="flex justify-between text-lg font-medium">
                  <span>Total</span>
                  <span>{formattedSubtotal}</span>
                </div>
              </div>

              <button className="w-full btn-primary py-4 flex items-center justify-center gap-2 group">
                Checkout <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>
              
              <p className="text-xs text-center text-muted-foreground mt-4">
                Secure checkout powered by Stripe
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
