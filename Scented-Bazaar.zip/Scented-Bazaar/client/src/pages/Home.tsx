import { useProducts } from "@/hooks/use-products";
import { ProductCard } from "@/components/ProductCard";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const { data: products, isLoading } = useProducts();
  const featuredProducts = products?.slice(0, 3) || [];

  return (
    <div className="space-y-24 pb-24">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Descriptive alt text for Unsplash: luxury perfume bottle on dark background with gold lighting */}
        <div className="absolute inset-0">
          <img 
            src="https://images.unsplash.com/photo-1595425970377-c97036c88f63?q=80&w=2072&auto=format&fit=crop"
            alt="Luxury perfume ambiance"
            className="w-full h-full object-cover brightness-50"
          />
        </div>
        
        <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-sm md:text-base uppercase tracking-[0.3em] mb-6 text-white/80"
          >
            The Essence of Elegance
          </motion.p>
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-5xl md:text-7xl lg:text-8xl font-display font-bold mb-8 leading-tight"
          >
            Timeless Scents <br />
            <span className="italic font-normal">for Modern Souls</span>
          </motion.h1>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <Link href="/products" className="inline-block bg-white text-black px-10 py-4 uppercase tracking-widest text-sm hover:bg-primary hover:text-white transition-colors duration-300">
              Discover Collection
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Featured Section */}
      <section className="container-custom">
        <div className="flex flex-col md:flex-row justify-between items-end mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-display mb-4">Curated Selections</h2>
            <p className="text-muted-foreground max-w-md">
              Our most coveted fragrances, chosen for their distinctive character and lasting impression.
            </p>
          </div>
          <Link href="/products" className="group flex items-center gap-2 text-sm uppercase tracking-widest mt-6 md:mt-0 hover:text-primary transition-colors">
            View All <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-[500px] bg-secondary animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>

      {/* Brand Story Teaser */}
      <section className="bg-secondary/30 py-24">
        <div className="container-custom grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="aspect-square relative overflow-hidden order-2 md:order-1">
            {/* Descriptive alt text: Close up of perfume ingredients, flowers and spices */}
            <img 
              src="https://images.unsplash.com/photo-1615634260167-c8cdede054de?q=80&w=1000&auto=format&fit=crop"
              alt="Ingredients"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="order-1 md:order-2 md:pl-12">
            <h2 className="text-3xl md:text-4xl font-display mb-6">Artistry in Every Drop</h2>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              We believe perfume is more than just a scent—it is an invisible accessory, 
              a personal signature, and a powerful trigger of memories. Our master perfumers 
              blend rare ingredients from around the world to create olfactory masterpieces.
            </p>
            <Link href="/products" className="btn-outline inline-block">
              Explore Our Story
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
