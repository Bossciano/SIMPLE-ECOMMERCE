import { useRoute } from "wouter";
import { useProduct } from "@/hooks/use-products";
import { useCart } from "@/hooks/use-cart";
import { Loader2, ArrowLeft, Check } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

export default function ProductDetail() {
  const [match, params] = useRoute("/product/:id");
  const id = parseInt(params?.id || "0");
  const { data: product, isLoading, error } = useProduct(id);
  const { addToCart, isAdding } = useCart();
  const [added, setAdded] = useState(false);

  const handleAddToCart = () => {
    if (product) {
      addToCart(product.id, {
        onSuccess: () => {
          setAdded(true);
          setTimeout(() => setAdded(false), 2000);
        }
      });
    }
  };

  if (isLoading) {
    return (
      <div className="h-[60vh] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center gap-4">
        <h2 className="text-2xl font-display">Product not found</h2>
        <Link href="/products" className="text-primary hover:underline">Return to collection</Link>
      </div>
    );
  }

  const formattedPrice = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(product.price / 100);

  return (
    <div className="min-h-screen py-12">
      <div className="container-custom">
        <Link href="/products" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4" /> Back to Collection
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24 items-start">
          {/* Image */}
          <div className="bg-secondary/20 aspect-[4/5] relative overflow-hidden group">
            <img 
              src={product.imageUrl} 
              alt={product.name}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
          </div>

          {/* Details */}
          <div className="sticky top-24 space-y-8">
            <div>
              <p className="text-sm uppercase tracking-widest text-primary font-bold mb-2">{product.brand}</p>
              <h1 className="text-4xl md:text-5xl font-display mb-4">{product.name}</h1>
              <p className="text-2xl font-medium">{formattedPrice}</p>
            </div>

            <div className="prose prose-stone max-w-none text-muted-foreground leading-relaxed">
              <p>{product.description}</p>
            </div>

            <div className="pt-8 border-t border-border">
              <button 
                onClick={handleAddToCart}
                disabled={isAdding || added}
                className={`w-full py-4 text-sm uppercase tracking-widest font-bold transition-all duration-300 flex items-center justify-center gap-2
                  ${added 
                    ? "bg-green-700 text-white" 
                    : "bg-foreground text-background hover:bg-primary hover:text-white"
                  }`}
              >
                {isAdding ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : added ? (
                  <>
                    <Check className="w-4 h-4" /> Added to Bag
                  </>
                ) : (
                  "Add to Cart"
                )}
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs uppercase tracking-widest text-muted-foreground pt-8">
              <div className="p-4 border border-border text-center">
                Free Shipping
              </div>
              <div className="p-4 border border-border text-center">
                Secure Checkout
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
