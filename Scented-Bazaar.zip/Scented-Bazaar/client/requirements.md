## Packages
framer-motion | Smooth entry animations and luxury transitions

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}

Cart logic requires a persistent sessionId in localStorage.
Images will use Unsplash URLs.
